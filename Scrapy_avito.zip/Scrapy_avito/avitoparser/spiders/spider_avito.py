# -*- coding: utf-8 -*-
import scrapy
from scrapy.http import HtmlResponse
from scrapy.loader import ItemLoader
from avitoparser.items import AvitoparserItem


class SpiderAvitoSpider(scrapy.Spider):
    name = 'spider_avito'
    allowed_domains = ['avito.ru']
    start_urls = ['https://www.avito.ru/rossiya/avtomobili']
    custom_settings = {
        'CLOSESPIDER_PAGECOUNT': '10',
        'CLOSESPIDER_ITEMCOUNT': '2'
    }

    def parse(self, response):
        next_page = response.xpath(
            "//a[@class='pagination-page js-pagination-next']/@href").get()
        if next_page:
            yield response.follow(next_page, callback=self.parse)

        car_ad = response.xpath('//a[@class="item-description-title-link"][@itemprop="url"]/@href').getall()

        for url in car_ad:
            yield response.follow(url, self.ad_parse)

    def ad_parse(self, response:HtmlResponse):
        loader = ItemLoader(item=AvitoparserItem(), response=response)
        loader.add_css('title', 'span.title-info-title-text::text')
        loader.add_xpath('photos',
                         '//div[contains(@class,"gallery-img-wrapper")]//div[contains(@class,"gallery-img-frame")]/@data-url')
        loader.add_value('url', response.url)

        yield loader.load_item()